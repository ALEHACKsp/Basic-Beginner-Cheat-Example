#include <Windows.h>

namespace Offsets
{
	//Local player 
	DWORD LocalPlayer = NULL;

	//Player Name
	DWORD Name = NULL;

	//Player HP
	DWORD PlayerHP = NULL;

	//Grenade
	DWORD Grenade = NULL;

	//Positions
	DWORD x = NULL;
	DWORD y = NULL;
	DWORD z = NULL;
}